const { ethers } = require('hardhat')
const PoolArtifact = require('../artifacts/contracts/MudswapPair.sol/MudswapPair.json')

const hash = ethers.utils.keccak256(PoolArtifact.bytecode)
console.log(hash)

